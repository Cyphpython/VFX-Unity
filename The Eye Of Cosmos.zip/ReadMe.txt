Unity Version : 2022.3.14f1
Template needed : Universal Render Pipeline (URP)